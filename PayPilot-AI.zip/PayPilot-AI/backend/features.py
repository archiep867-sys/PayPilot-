"""Convenience features. All numbers come from code/catalogue, never from the LLM."""
import re, json
from backend import db, orchestrator
from backend.agents import discovery_agent, payment_agent
from backend.services import catalogue, optimizer

async def compare(text, budget=None):
    d = await discovery_agent.run(text, budget or 100.0)
    if budget: d["budget"] = budget
    if not d["requirements"]: return {"status": "no_requirements", "carts": {}}
    pool = {r["category"]: catalogue.search(r["category"]) for r in d["requirements"]}
    carts = {}
    for prio, label in (("cheap", "Cheapest"), ("balanced", "Balanced"), ("quality", "Best quality")):
        c = optimizer.optimize(d["requirements"], pool, d["budget"], prio)
        c["label"] = label; c["avg_quality"] = round(sum(i["quality"] * i["quantity"] for i in c["items"]) / max(1, sum(i["quantity"] for i in c["items"])), 2)
        carts[prio] = c
    order = [d["priority"], "balanced", "cheap"]
    pick = next((p for p in order if carts[p]["status"] == "ok"), None)
    why = (f"{carts[pick]['label']} fits your ${d['budget']:.2f} budget at ${carts[pick]['total']:.2f} (average quality {carts[pick]['avg_quality']}/5)." if pick
           else "None of the three carts fit the budget. Raise the budget or reduce quantities.")
    return {"status": "ok" if pick else "over_budget", "request": d, "carts": carts, "recommended": pick, "reason": why}

def analytics():
    txs = [t for t in db.list_tx() if t["status"] == "COMPLETED"]
    by_cat, saved, spent = {}, 0.0, 0.0
    for t in txs:
        spent += t["amount"]
        for l in json.loads(t["items"]):
            p = catalogue.get(l["id"])
            if not p: continue
            by_cat[p["category"]] = round(by_cat.get(p["category"], 0) + l["unit_price"] * l["quantity"], 2)
            top = max(x["price"] for x in catalogue.by_category(p["category"]))
            saved += (top - l["unit_price"]) * l["quantity"]
    return {"total_spent": round(spent, 2), "orders": len(txs), "by_category": by_cat,
            "saved_vs_priciest": round(saved, 2), "refunded": sum(1 for t in db.list_tx() if t["status"] == "REFUNDED")}

def receipt(order_id):
    t = db.get_tx(order_id)
    if not t: return None
    lines = json.loads(t["items"]); cart = db.load_cart(t["cart_id"]) or {}
    return {"order_id": order_id, "capture_id": t["capture_id"], "status": t["status"], "amount": t["amount"], "currency": t["currency"],
            "items": lines, "reasoning": cart.get("cart", {}).get("explanation", ""), "agent_trace": db.logs_for(t["cart_id"]),
            "note": "PayPal Sandbox demo order from a demo catalogue. No real money moved."}

def receipt_text(r):
    rows = "\n".join(f"  {l['quantity']} x {l['name']} @ ${l['unit_price']:.2f}" for l in r["items"])
    return f"PayPilot receipt\nOrder {r['order_id']} | {r['status']}\n{rows}\nTotal: ${r['amount']:.2f} {r['currency']}\n\nWhy: {r['reasoning']}\n\n{r['note']}\n"

def _num(pats, t):
    for p in pats:
        m = re.search(p, t)
        if m: return float(m.group(1))
def propose_rules(text):
    """Plain English -> PROPOSED limits. Never applied until the user confirms via PUT /api/settings."""
    t = text.lower(); cur = db.get_rules(); new = dict(cur)
    a = _num([r"auto\w*\D{0,30}\$?(\d+(?:\.\d+)?)", r"(?:without asking|no approval)\D{0,20}\$?(\d+(?:\.\d+)?)"], t)
    q = _num([r"(?:ask|approv\w*|confirm\w*)\D{0,30}(?:over|above|more than|beyond|up to)\D{0,4}\$?(\d+(?:\.\d+)?)", r"(?:over|above|more than)\s*\$?(\d+(?:\.\d+)?)\D{0,30}(?:ask|approv|confirm)"], t)
    m = _num([r"never\D{0,30}\$?(\d+(?:\.\d+)?)", r"(?:max\w*|cap|limit)\D{0,20}\$?(\d+(?:\.\d+)?)"], t)
    if a is not None: new["auto_limit"] = a
    if q is not None: new["approval_limit"] = q
    if m is not None: new["max_per_purchase"] = m
    ok = 0 <= new["auto_limit"] <= new["approval_limit"] <= new["max_per_purchase"]
    return {"current": cur, "proposed": new, "valid": ok, "changed": new != cur,
            "message": "Review and confirm to apply." if ok else "These limits conflict (auto <= approval <= max). Please rephrase."}
